import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employed',
  templateUrl: './employed.component.html',
  styleUrls: ['./employed.component.css']
})
export class EmployedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}