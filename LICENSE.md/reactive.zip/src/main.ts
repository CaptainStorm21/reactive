import './polyfills';

import {HttpClientModule} from '@angular/common/http';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatNativeDateModule} from '@angular/material/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {DemoMaterialModule} from './material-module';
import { PersonalInfoComponent } from './app/personal-info/personal-info/personal-info.component';
import {ExpansionOverviewExample} from './app/expansion-overview-example';
import { FullNameComponent } from './app/personal-info/full-name/full-name.component';
import { AccordionComponent } from './app/accordion/accordion.component';
import { ResidenceComponent } from './app/residence/residence.component';
import { EmploymentComponent } from './app/employment/employment.component';
import { StudentComponent } from './app/student/student.component';
import { EmployedComponent } from './app/employed/employed.component';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    DemoMaterialModule,
    MatNativeDateModule,
    ReactiveFormsModule,
  ],
  entryComponents: [ExpansionOverviewExample],
  declarations: [ExpansionOverviewExample, EmploymentComponent, PersonalInfoComponent, StudentComponent, FullNameComponent, ResidenceComponent,AccordionComponent, EmployedComponent ],
  bootstrap: [ExpansionOverviewExample],
  providers: []
})
export class AppModule {}

platformBrowserDynamic().bootstrapModule(AppModule);


/**  Copyright 2019 Google Inc. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */